$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$mods = @(
    @{ slug = "the-lost-cities"; label = "The Lost Cities" },
    @{ slug = "fabric-api"; label = "Fabric API" },
    @{ slug = "forge-config-api-port"; label = "Forge Config API Port" },
    @{ slug = "sodium"; label = "Sodium" },
    @{ slug = "lithium"; label = "Lithium" },
    @{ slug = "ferrite-core"; label = "FerriteCore" },
    @{ slug = "entityculling"; label = "Entity Culling" },
    @{ slug = "immediatelyfast"; label = "ImmediatelyFast" }
)

Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "       LAST SURVIVOR: LITE INSTALLER" -ForegroundColor Cyan
Write-Host "          Minecraft 26.3 / Fabric" -ForegroundColor Gray
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Choose the Minecraft game folder. For Legacy Launcher,"
Write-Host "select the folder used by your Fabric 26.3 profile."
Write-Host ""

Add-Type -AssemblyName System.Windows.Forms
$dialog = New-Object System.Windows.Forms.FolderBrowserDialog
$dialog.Description = "Select your Minecraft game directory (the folder containing or intended to contain mods)"
$dialog.ShowNewFolderButton = $true
if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
    Write-Host "Cancelled. No files were changed." -ForegroundColor Yellow
    Read-Host "Press Enter to close"
    exit
}
$gameDir = $dialog.SelectedPath
$modsDir = Join-Path $gameDir "mods"
New-Item -ItemType Directory -Force -Path $modsDir | Out-Null

# Back up any existing files with the same pack filenames.
$backupDir = Join-Path $gameDir ("LastSurvivor_backup_" + (Get-Date -Format "yyyyMMdd_HHmmss"))
$downloaded = 0
$failed = @()

foreach ($mod in $mods) {
    try {
        Write-Host ("Checking " + $mod.label + "...") -ForegroundColor Cyan
        $api = "https://api.modrinth.com/v2/project/$($mod.slug)/version?game_versions=%5B%2226.3%22%5D&loaders=%5B%22fabric%22%5D"
        $versions = Invoke-RestMethod -Uri $api -Headers @{ "User-Agent" = "LastSurvivorLite/1.0 (modpack installer)" }
        $release = $versions |
            Where-Object { $_.version_type -eq "release" -and $_.files.Count -gt 0 } |
            Sort-Object { [datetime]$_.date_published } -Descending |
            Select-Object -First 1

        if (-not $release) {
            throw "No stable Fabric 26.3 file was found in Modrinth metadata."
        }

        $file = $release.files | Where-Object { $_.primary -eq $true } | Select-Object -First 1
        if (-not $file) { $file = $release.files | Select-Object -First 1 }
        if (-not $file) { throw "The release has no downloadable file." }

        $destination = Join-Path $modsDir $file.filename
        if (Test-Path $destination) {
            if (-not (Test-Path $backupDir)) { New-Item -ItemType Directory -Force -Path $backupDir | Out-Null }
            Move-Item -Force $destination (Join-Path $backupDir $file.filename)
        }

        Invoke-WebRequest -Uri $file.url -OutFile $destination -Headers @{ "User-Agent" = "LastSurvivorLite/1.0 (modpack installer)" }
        Write-Host ("  Installed: " + $file.filename) -ForegroundColor Green
        $downloaded++
    }
    catch {
        $failed += ($mod.label + ": " + $_.Exception.Message)
        Write-Host ("  Could not install " + $mod.label) -ForegroundColor Yellow
    }
}

Write-Host ""
Write-Host "Finished: $downloaded of $($mods.Count) mods downloaded." -ForegroundColor Cyan
if ($failed.Count -gt 0) {
    Write-Host ""
    Write-Host "Some downloads failed:" -ForegroundColor Yellow
    $failed | ForEach-Object { Write-Host (" - " + $_) }
}
Write-Host ""
Write-Host "Next steps:" -ForegroundColor White
Write-Host "1. Make sure Fabric Loader for Minecraft 26.3 is installed."
Write-Host "2. Start the Fabric 26.3 profile in Legacy Launcher."
Write-Host "3. Create a NEW world and choose The Lost Cities profile in world creation."
Write-Host "4. Keep a backup of your worlds before adding or updating mods."
Write-Host ""
Write-Host "This installer only downloads files from Modrinth's official project API/CDN."
Read-Host "Press Enter to close"
