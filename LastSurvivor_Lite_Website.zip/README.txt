LAST SURVIVOR: LITE — Minecraft 26.3 / Fabric
================================================

WHAT THIS PACK DOES
- The Lost Cities: generates an abandoned city world.
- Sodium, Lithium, FerriteCore, Entity Culling, ImmediatelyFast: performance helpers.
- Fabric API and Forge Config API Port: required libraries for the city mod.

INSTALLATION
1. Install Fabric Loader for Minecraft 26.3 in Legacy Launcher.
2. Unzip this package.
3. Double-click INSTALL.bat.
4. Choose the game directory used by your Legacy Launcher Fabric 26.3 profile.
   It should be the directory where the "mods" folder belongs.
5. Wait for the installer to fetch the latest stable Fabric 26.3 versions from Modrinth.
6. Start the Fabric 26.3 profile.
7. Create a NEW world. In the world creation screen, open the Cities option/profile
   and select the Lost Cities profile. The exact menu wording can vary by mod version.

IMPORTANT
- This installer needs an internet connection and Windows PowerShell.
- It downloads stable releases matching Minecraft 26.3 + Fabric from Modrinth.
- It does not install Minecraft, Java, or Fabric Loader.
- Make a backup of existing worlds first.
- The pack is intentionally small, but no performance guarantee is possible on
  every 4 GB computer. Close other programs and begin with 5 render distance
  and 4 simulation distance.
- If a download is unavailable, check the official Modrinth project page.
- The installer does not download weapons, weapon accessories, or combat gear.

OFFICIAL PROJECT PAGES
The Lost Cities: https://modrinth.com/mod/the-lost-cities
Fabric API: https://modrinth.com/mod/fabric-api
Forge Config API Port: https://modrinth.com/mod/forge-config-api-port
Sodium: https://modrinth.com/mod/sodium
Lithium: https://modrinth.com/mod/lithium
FerriteCore: https://modrinth.com/mod/ferrite-core
Entity Culling: https://modrinth.com/mod/entityculling
ImmediatelyFast: https://modrinth.com/mod/immediatelyfast
